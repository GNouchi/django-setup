from django.apps import AppConfig


class BlogsappConfig(AppConfig):
    name = 'blogsapp'
